﻿### Variables
$TimeStamp = Get-Date
$ScriptDir = "C:\InSpark\"
$GPODir = "C:\InSpark\Extracted\OS_Vulnerabilities"

# Create script Folder
New-Item -Path $ScriptDir -ItemType Directory -ErrorAction Continue
# Create Folder for logging
$LogDir = "C:\InSpark\Log"
$LogFile = "C:\InSpark\Log\Script.log"
New-Item -Path $LogDir -ItemType Directory -ErrorAction Continue

# Functions
Function LogWrite {
    Param ([string]$logstring)
    Add-content $Logfile -value $logstring 
}

# Starting script
$TimeStamp = Get-Date
LogWrite "$TimeStamp - Script started"

# Search for the latest ZIP File
$customScriptPath = 'C:\Packages\Plugins\Microsoft.Compute.CustomScriptExtension\1.9\Downloads' 
$ZIPFile = Get-Childitem –Path $customScriptPath -Include *.ZIP -Recurse 
$ZIPFile.DirectoryName
Copy-Item $ZIPFile $ScriptDir

### Proces the ZIP file
$ZIPSrc = $ScriptDir + $ZIPFile.Name
$ZIPDst = $ScriptDir+ '\Extracted\'
New-Item -Path $ZIPDst -ItemType Directory -ErrorAction Continue
$TimeStamp = Get-Date
LogWrite "$timeStamp - Zip file = $ZIPFile"
LogWrite "$TimeStamp - ZIP Source is:$ZIPSrc"
LogWrite "$TimeStamp - ZIP Destination is:$ZIPDst"
# Unzip the file 
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Unzip {
    param([string]$zipfile, [string]$outpath)

    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
}
Unzip "$ZIPSrc" "$ZIPDst"

### Get OS Version
$OSVersion = (gwmi win32_operatingsystem).caption

if ($OSVersion -eq "Microsoft Windows Server 2012 R2 Datacenter") {
    $TimeStamp = Get-Date
    Write-Host "$TimeStamp OS Version is Microsoft Windows Server 2012 R2 Datacenter"
    LogWrite "$TimeStamp OS Version is Microsoft Windows Server 2012 R2 Datacenter"

    ### MSS Settings - Disable AutoAdminLogon - CCE-ID - CCE-37067-6
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Set MSS Settings - Disable AutoAdminLogon - CCE-ID - CCE-37067-6"
    $RegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\"
    $RegName = "AutoAdminLogon"
    $RegValue = "0"
    New-ItemProperty -Path $RegPath -Name $RegName -Value $RegValue


    ### MSS Settings - SafeDllSearchMode - CCE-ID - CCE-36351-5
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Set MSS Settings - SafeDllSearchMode - CCE-ID - CCE-36351-5"
    $RegPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\"
    $RegName = "SafeDllSearchMode"
    $RegValue = "1"
    New-ItemProperty -Path $RegPath -Name $RegName -Value $RegValue -PropertyType "DWord"


    ### MSS Settings - Screen Saver GracePeriod - CCE-ID - CCE-37993-3
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Set MSS Settings - Screen Saver GracePeriod - CCE-ID - CCE-37993-3"
    $RegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\"
    $RegName = "ScreenSaverGracePeriod"
    $RegValue = "5"
    New-ItemProperty -Path $RegPath -Name $RegName -Value $RegValue


    ### MSS Settings - Disable IP SourceRouting (IPv6) - CCE-ID - CCE-36871-2
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Set MSS Settings - Disable IP SourceRouting (IPv6) - CCE-ID - CCE-36871-2"
    $RegPath = "HKLM:\System\CurrentControlSet\Services\Tcpip6\Parameters"
    $RegName = "DisableIPSourceRouting"
    $RegValue = "2"
    New-ItemProperty -Path $RegPath -Name $RegName -Value $RegValue -PropertyType "DWord"


    ### MSS Settings - Disable IP SourceRouting (IPv4) - CCE-ID - CCE-36535-3
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Set MSS Settings - Disable IP SourceRouting (IPv4) - CCE-ID - CCE-36535-3"
    $RegPath = "HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters"
    $RegName = "DisableIPSourceRouting"
    $RegValue = "2"
    New-ItemProperty -Path $RegPath -Name $RegName -Value $RegValue -PropertyType "DWord"

    ### MSS Settings - Eventlog WarningLevel - CCE-ID - CCE-36880-3
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Set MSS Settings - Eventlog WarningLevel - CCE-ID - CCE-36880-3"
    $RegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security"
    $RegName = "WarningLevel"
    $RegValue = "90"
    New-ItemProperty -Path $RegPath -Name $RegName -Value $RegValue -PropertyType "DWord"


    ### Restore GPO Backup with OS vulnerability fixes
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Started with GPO Restore"
    $LGPOCMD = $GPODir + "\LGPO\LGPO.exe"
    $GPOPath = $GPODir+ "\GPO_BACKUP\WS-2012R2"
    $ARG = "/g", $GPOPath
    Start-Process -FilePath $LGPOCMD -ArgumentList $ARG






}
elseif ($OSVersion -eq "Microsoft Windows Server 2016 Datacenter") {
    $TimeStamp = Get-Date
    Write-Host "$TimeStamp OS Version is Microsoft Windows Server 2016 Datacenter"
    LogWrite "$TimeStamp OS Version is Microsoft Windows Server 2016 Datacenter"

    ### Enable 'Scan removable drives' by setting DisableRemovableDriveScanning  to 0
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Enable 'Scan removable drives' by setting DisableRemovableDriveScanning  to 0"
    Set-MpPreference -DisableRemovableDriveScanning 0


    ### Disable SMBv1
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Disable SMBv10"
    Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force


    ### Restore GPO Backup with OS vulnerability fixes
    $TimeStamp = Get-Date
    LogWrite "$TimeStamp Started with GPO Restore"
    $LGPOCMD = $GPODir + "\LGPO\LGPO.exe"
    $GPOPath = $GPODir + "\GPO_BACKUP\WS-2016"
    $ARG = "/g", $GPOPath
    Start-Process -FilePath $LGPOCMD -ArgumentList $ARG

}
